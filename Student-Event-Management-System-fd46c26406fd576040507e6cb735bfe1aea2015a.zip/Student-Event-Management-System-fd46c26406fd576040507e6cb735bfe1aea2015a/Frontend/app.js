const API_BASE = 'https://localhost:7044/api';

// Toast Notification System
function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container') || createToastContainer();
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    
    container.appendChild(toast);
    
    // Trigger animation
    setTimeout(() => toast.classList.add('show'), 10);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
    return container;
}

// Loader System
function toggleLoader(show) {
    const loader = document.getElementById('loader');
    if (loader) {
        if (show) loader.classList.add('active');
        else loader.classList.remove('active');
    }
}

// API Call Wrapper
async function apiCall(endpoint, method = 'GET', body = null) {
    toggleLoader(true);
    try {
        const options = {
            method,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        if (body) options.body = JSON.stringify(body);

        const response = await fetch(`${API_BASE}${endpoint}`, options);
        
        let data = null;
        if (response.status !== 204) { // 204 No Content for DELETE
            try { data = await response.json(); } catch(e) {}
        }

        if (response.status === 201) {
            showToast('Created successfully!', 'success');
            return data;
        }
        
        if (response.ok) {
            return data;
        }

        // Error Handling
        if (response.status === 400) {
            showToast(data?.message || typeof data === 'string' ? data : 'Bad Request', 'error');
        } else if (response.status === 404) {
            showToast('Not found', 'error');
        } else if (response.status === 409) {
            showToast('Already registered', 'warning');
        } else {
            showToast('Something went wrong', 'error');
        }
        throw new Error('API Error');
    } catch (error) {
        console.error('API Call Failed:', error);
        throw error;
    } finally {
        toggleLoader(false);
    }
}

// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', () => {
    const toggleBtn = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });
    }

    // Add loader to page
    if (!document.getElementById('loader')) {
        const loader = document.createElement('div');
        loader.id = 'loader';
        loader.className = 'loader-overlay';
        loader.innerHTML = '<div class="spinner"></div>';
        document.body.appendChild(loader);
    }
});

// Utility to format dates
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
}
