using System;
using System.ComponentModel.DataAnnotations;

namespace StudentEventAPI.DTOs
{
    public class CreateEventDto
    {
        [Required]
        [MaxLength(100)]
        public string Title { get; set; } = string.Empty;

        [Required]
        [MaxLength(500)]
        public string Description { get; set; } = string.Empty;

        [Required]
        public DateTime Date { get; set; }

        [Required]
        [MaxLength(100)]
        public string Venue { get; set; } = string.Empty;
    }
}
