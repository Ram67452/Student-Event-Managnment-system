using System.ComponentModel.DataAnnotations;

namespace StudentEventAPI.DTOs
{
    public class CreateStudentDto
    {
        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [MaxLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string StudentId { get; set; } = string.Empty;
    }
}
