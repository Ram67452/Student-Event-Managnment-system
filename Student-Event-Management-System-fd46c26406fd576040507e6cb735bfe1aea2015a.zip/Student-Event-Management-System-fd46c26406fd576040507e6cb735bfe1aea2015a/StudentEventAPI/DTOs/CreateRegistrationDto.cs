using System.ComponentModel.DataAnnotations;

namespace StudentEventAPI.DTOs
{
    public class CreateRegistrationDto
    {
        [Required]
        public int StudentId { get; set; }

        [Required]
        public int EventId { get; set; }
    }
}
