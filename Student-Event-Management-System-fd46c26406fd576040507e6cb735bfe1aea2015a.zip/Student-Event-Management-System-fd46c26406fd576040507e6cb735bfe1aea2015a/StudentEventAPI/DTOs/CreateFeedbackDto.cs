using System.ComponentModel.DataAnnotations;

namespace StudentEventAPI.DTOs
{
    public class CreateFeedbackDto
    {
        [Required]
        public int EventId { get; set; }

        [Required]
        public int StudentId { get; set; }

        [Required]
        [Range(1, 5)]
        public int Rating { get; set; }

        [MaxLength(500)]
        public string Comment { get; set; } = string.Empty;
    }
}
