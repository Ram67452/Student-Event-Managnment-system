using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using StudentEventAPI.Data;
using StudentEventAPI.DTOs;
using StudentEventAPI.Models;

namespace StudentEventAPI.Services
{
    public class FeedbackService : IFeedbackService
    {
        private readonly ApplicationDbContext _context;

        public FeedbackService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<FeedbackDto> SubmitFeedbackAsync(CreateFeedbackDto dto)
        {
            var ev = await _context.Events.FindAsync(dto.EventId);
            if (ev == null)
            {
                throw new ArgumentException("Event not found.");
            }

            if (ev.Date >= DateTime.Now)
            {
                throw new InvalidOperationException("Cannot submit feedback for a future event.");
            }

            var feedback = new Feedback
            {
                EventId = dto.EventId,
                StudentId = dto.StudentId,
                Rating = dto.Rating,
                Comment = dto.Comment,
                SubmittedAt = DateTime.Now
            };

            _context.Feedbacks.Add(feedback);
            await _context.SaveChangesAsync();

            return new FeedbackDto
            {
                Id = feedback.Id,
                EventId = feedback.EventId,
                StudentId = feedback.StudentId,
                Rating = feedback.Rating,
                Comment = feedback.Comment,
                SubmittedAt = feedback.SubmittedAt
            };
        }
        
        public async Task<IEnumerable<FeedbackDto>> GetFeedbackForEventAsync(int eventId)
        {
            var feedbacks = await _context.Feedbacks
                .Where(f => f.EventId == eventId)
                .ToListAsync();
                
            return feedbacks.Select(f => new FeedbackDto
            {
                Id = f.Id,
                EventId = f.EventId,
                StudentId = f.StudentId,
                Rating = f.Rating,
                Comment = f.Comment,
                SubmittedAt = f.SubmittedAt
            });
        }
    }
}
