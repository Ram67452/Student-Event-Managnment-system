using System.Collections.Generic;
using System.Threading.Tasks;
using StudentEventAPI.DTOs;

namespace StudentEventAPI.Services
{
    public interface IEventService
    {
        Task<IEnumerable<EventDto>> GetAllUpcomingEventsAsync();
        Task<EventDto?> GetEventByIdAsync(int id);
        Task<EventDto> CreateEventAsync(CreateEventDto dto);
        Task<EventDto?> UpdateEventAsync(int id, UpdateEventDto dto);
        Task<bool> DeleteEventAsync(int id);
        Task<IEnumerable<EventDto>> SearchEventsAsync(string query);
        Task<IEnumerable<EventDto>> FilterEventsAsync(string sort);
    }
}
