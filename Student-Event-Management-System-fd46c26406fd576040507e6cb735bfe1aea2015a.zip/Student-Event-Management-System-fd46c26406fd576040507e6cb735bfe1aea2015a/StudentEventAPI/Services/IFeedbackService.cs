using System.Threading.Tasks;
using StudentEventAPI.DTOs;

namespace StudentEventAPI.Services
{
    public interface IFeedbackService
    {
        Task<FeedbackDto> SubmitFeedbackAsync(CreateFeedbackDto dto);
        Task<System.Collections.Generic.IEnumerable<FeedbackDto>> GetFeedbackForEventAsync(int eventId);
    }
}
