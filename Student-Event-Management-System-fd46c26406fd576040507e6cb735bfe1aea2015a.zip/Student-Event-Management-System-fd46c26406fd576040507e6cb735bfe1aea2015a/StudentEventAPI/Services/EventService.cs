using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using StudentEventAPI.Data;
using StudentEventAPI.DTOs;
using StudentEventAPI.Models;

namespace StudentEventAPI.Services
{
    public class EventService : IEventService
    {
        private readonly ApplicationDbContext _context;

        public EventService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<EventDto>> GetAllUpcomingEventsAsync()
        {
            var events = await _context.Events
                .Where(e => e.Date >= DateTime.Now)
                .ToListAsync();

            return events.Select(e => new EventDto
            {
                Id = e.Id,
                Title = e.Title,
                Description = e.Description,
                Date = e.Date,
                Venue = e.Venue,
                CreatedAt = e.CreatedAt
            });
        }

        public async Task<EventDto?> GetEventByIdAsync(int id)
        {
            var e = await _context.Events.FindAsync(id);
            if (e == null) return null;

            return new EventDto
            {
                Id = e.Id,
                Title = e.Title,
                Description = e.Description,
                Date = e.Date,
                Venue = e.Venue,
                CreatedAt = e.CreatedAt
            };
        }

        public async Task<EventDto> CreateEventAsync(CreateEventDto dto)
        {
            var newEvent = new Event
            {
                Title = dto.Title,
                Description = dto.Description,
                Date = dto.Date,
                Venue = dto.Venue,
                CreatedAt = DateTime.Now
            };

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();

            return new EventDto
            {
                Id = newEvent.Id,
                Title = newEvent.Title,
                Description = newEvent.Description,
                Date = newEvent.Date,
                Venue = newEvent.Venue,
                CreatedAt = newEvent.CreatedAt
            };
        }

        public async Task<EventDto?> UpdateEventAsync(int id, UpdateEventDto dto)
        {
            var e = await _context.Events.FindAsync(id);
            if (e == null) return null;

            e.Title = dto.Title;
            e.Description = dto.Description;
            e.Date = dto.Date;
            e.Venue = dto.Venue;

            await _context.SaveChangesAsync();

            return new EventDto
            {
                Id = e.Id,
                Title = e.Title,
                Description = e.Description,
                Date = e.Date,
                Venue = e.Venue,
                CreatedAt = e.CreatedAt
            };
        }

        public async Task<bool> DeleteEventAsync(int id)
        {
            var e = await _context.Events.FindAsync(id);
            if (e == null) return false;

            _context.Events.Remove(e);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<EventDto>> SearchEventsAsync(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return await GetAllUpcomingEventsAsync();

            var lowerQuery = query.ToLower();
            var events = await _context.Events
                .Where(e => e.Title.ToLower().Contains(lowerQuery) || e.Venue.ToLower().Contains(lowerQuery))
                .ToListAsync();

            return events.Select(e => new EventDto
            {
                Id = e.Id,
                Title = e.Title,
                Description = e.Description,
                Date = e.Date,
                Venue = e.Venue,
                CreatedAt = e.CreatedAt
            });
        }

        public async Task<IEnumerable<EventDto>> FilterEventsAsync(string sort)
        {
            var query = _context.Events.AsQueryable();
            var lowerSort = sort.ToLower();

            if (lowerSort == "date")
            {
                query = query.OrderBy(e => e.Date);
            }
            else if (lowerSort == "venue")
            {
                query = query.OrderBy(e => e.Venue);
            }

            var events = await query.ToListAsync();

            return events.Select(e => new EventDto
            {
                Id = e.Id,
                Title = e.Title,
                Description = e.Description,
                Date = e.Date,
                Venue = e.Venue,
                CreatedAt = e.CreatedAt
            });
        }
    }
}
