using System.Collections.Generic;
using System.Threading.Tasks;
using StudentEventAPI.DTOs;

namespace StudentEventAPI.Services
{
    public interface IRegistrationService
    {
        Task<RegistrationDto> RegisterStudentAsync(CreateRegistrationDto dto);
        Task<IEnumerable<RegistrationDto>> GetRegistrationsByStudentAsync(int studentId);
    }
}
