using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using StudentEventAPI.Data;
using StudentEventAPI.DTOs;
using StudentEventAPI.Models;

namespace StudentEventAPI.Services
{
    public class RegistrationService : IRegistrationService
    {
        private readonly ApplicationDbContext _context;

        public RegistrationService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<RegistrationDto> RegisterStudentAsync(CreateRegistrationDto dto)
        {
            // Check for duplicate registration
            var existingRegistration = await _context.Registrations
                .FirstOrDefaultAsync(r => r.StudentId == dto.StudentId && r.EventId == dto.EventId);

            if (existingRegistration != null)
            {
                throw new InvalidOperationException("Duplicate registration.");
            }

            var registration = new Registration
            {
                StudentId = dto.StudentId,
                EventId = dto.EventId,
                RegisteredAt = DateTime.Now
            };

            _context.Registrations.Add(registration);
            await _context.SaveChangesAsync();

            return new RegistrationDto
            {
                Id = registration.Id,
                StudentId = registration.StudentId,
                EventId = registration.EventId,
                RegisteredAt = registration.RegisteredAt
            };
        }

        public async Task<IEnumerable<RegistrationDto>> GetRegistrationsByStudentAsync(int studentId)
        {
            var registrations = await _context.Registrations
                .Where(r => r.StudentId == studentId)
                .ToListAsync();

            return registrations.Select(r => new RegistrationDto
            {
                Id = r.Id,
                StudentId = r.StudentId,
                EventId = r.EventId,
                RegisteredAt = r.RegisteredAt
            });
        }
    }
}
