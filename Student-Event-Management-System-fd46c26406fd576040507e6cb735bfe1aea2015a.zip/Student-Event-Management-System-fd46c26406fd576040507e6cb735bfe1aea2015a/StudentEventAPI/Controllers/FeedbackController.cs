using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StudentEventAPI.DTOs;
using StudentEventAPI.Services;

namespace StudentEventAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FeedbackController : ControllerBase
    {
        private readonly IFeedbackService _feedbackService;

        public FeedbackController(IFeedbackService feedbackService)
        {
            _feedbackService = feedbackService;
        }

        [HttpPost]
        public async Task<ActionResult<FeedbackDto>> SubmitFeedback([FromBody] CreateFeedbackDto dto)
        {
            try
            {
                var feedback = await _feedbackService.SubmitFeedbackAsync(dto);
                return CreatedAtAction(nameof(GetFeedbackForEvent), new { eventId = feedback.EventId }, feedback);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception)
            {
                return BadRequest("Failed to submit feedback.");
            }
        }

        [HttpGet("{eventId}")]
        public async Task<ActionResult<System.Collections.Generic.IEnumerable<FeedbackDto>>> GetFeedbackForEvent(int eventId)
        {
            var feedback = await _feedbackService.GetFeedbackForEventAsync(eventId);
            return Ok(feedback);
        }
    }
}
