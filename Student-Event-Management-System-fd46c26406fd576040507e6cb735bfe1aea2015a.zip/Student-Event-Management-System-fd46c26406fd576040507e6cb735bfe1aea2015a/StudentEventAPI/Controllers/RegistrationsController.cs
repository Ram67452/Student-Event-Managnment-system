using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StudentEventAPI.DTOs;
using StudentEventAPI.Services;

namespace StudentEventAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RegistrationsController : ControllerBase
    {
        private readonly IRegistrationService _registrationService;

        public RegistrationsController(IRegistrationService registrationService)
        {
            _registrationService = registrationService;
        }

        [HttpPost]
        public async Task<ActionResult<RegistrationDto>> RegisterStudent([FromBody] CreateRegistrationDto dto)
        {
            try
            {
                var registration = await _registrationService.RegisterStudentAsync(dto);
                return CreatedAtAction(nameof(GetStudentRegistrations), new { studentId = registration.StudentId }, registration);
            }
            catch (InvalidOperationException)
            {
                return Conflict("Duplicate registration is not allowed.");
            }
            catch (Exception)
            {
                return BadRequest("Failed to register.");
            }
        }

        [HttpGet("{studentId}")]
        public async Task<ActionResult<IEnumerable<RegistrationDto>>> GetStudentRegistrations(int studentId)
        {
            var registrations = await _registrationService.GetRegistrationsByStudentAsync(studentId);
            return Ok(registrations);
        }
    }
}
