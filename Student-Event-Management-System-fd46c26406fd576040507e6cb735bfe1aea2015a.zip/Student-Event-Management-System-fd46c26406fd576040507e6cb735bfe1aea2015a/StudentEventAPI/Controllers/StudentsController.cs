using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentEventAPI.Data;
using StudentEventAPI.DTOs;
using StudentEventAPI.Models;

namespace StudentEventAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StudentsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        // Using DbContext directly here as IStudentService was not explicitly requested
        public StudentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<StudentDto>>> GetStudents()
        {
            var students = await _context.Students.ToListAsync();
            var dtos = new List<StudentDto>();
            foreach(var s in students)
            {
                dtos.Add(new StudentDto { Id = s.Id, Name = s.Name, Email = s.Email, StudentId = s.StudentId });
            }
            return Ok(dtos);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<StudentDto>> GetStudent(int id)
        {
            var s = await _context.Students.FindAsync(id);
            if (s == null) return NotFound();

            return Ok(new StudentDto { Id = s.Id, Name = s.Name, Email = s.Email, StudentId = s.StudentId });
        }

        [HttpPost]
        public async Task<ActionResult<StudentDto>> CreateStudent([FromBody] CreateStudentDto dto)
        {
            var student = new Student
            {
                Name = dto.Name,
                Email = dto.Email,
                StudentId = dto.StudentId
            };

            _context.Students.Add(student);
            await _context.SaveChangesAsync();

            var studentDto = new StudentDto { Id = student.Id, Name = student.Name, Email = student.Email, StudentId = student.StudentId };
            return CreatedAtAction(nameof(GetStudent), new { id = student.Id }, studentDto);
        }
    }
}
